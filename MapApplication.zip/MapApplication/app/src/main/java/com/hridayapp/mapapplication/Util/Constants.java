package com.hridayapp.mapapplication.Util;

public class Constants {
    public static final String url = "https://earthquake.usgs.gov/earthquakes/feed/v1.0/summary/4.5_month.geojson";
    public static final int LIMIT = 100;


}
